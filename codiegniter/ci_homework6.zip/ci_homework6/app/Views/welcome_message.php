<?= $this->extend('layouts/layout') ?>

<?= $this->section('content') ?>
    <div class="container mt-4">
    <h1 class = "text-center text-info mt-5">Welcom Ci4 Crud Student</h1>
    </div>
<?= $this->endSection() ?>