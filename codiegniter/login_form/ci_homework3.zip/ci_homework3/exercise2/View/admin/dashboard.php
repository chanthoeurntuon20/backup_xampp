
<?= $this->extend('layouts/layout');?>
    <?= $this->section('content')?>
    <h1 class = "text-danger">Dashboard views</h1>
    <?= $this->endSection() ?>
    