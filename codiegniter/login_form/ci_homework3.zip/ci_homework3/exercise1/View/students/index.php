<h1>Student default views</h1>
