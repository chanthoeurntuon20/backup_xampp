    
    <?= $this->extend('layouts/layout');?>
    <?= $this->section('content')?>
    <h1 class = "text-info"> Admin default views </h1> 
    
    <?= $this->endSection() ?>
    