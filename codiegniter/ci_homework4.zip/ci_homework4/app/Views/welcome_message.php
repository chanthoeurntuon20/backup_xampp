<?= $this->extend('layouts/layout') ?>

<?= $this->section('content') ?>
    <h1 class = "text-center text-info display-4 mt-5">Welcome student information</h1>
<?= $this->endSection() ?>